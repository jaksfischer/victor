<?php

$nome = trim($_POST['nome']);
$email = trim($_POST['email']);

#Podemos criar uma validação bem simples, criando uma validação e definindo quais os campos são obrigatórios, por exemplo, digamo que o nome seja obrigatório
$erro = 0; //Esta variável inicia em 0, caso encontre algum campo vazio, ela recebera sempre +1, sendo assim, faremos a validação dizendo que se ela estiver
// com um valor diferente de 0, assumimos que possui algum erro.

function validaCampoObrigatorio($post, $campo, $erro)
{
    if(!$post[$campo]) {
        return $erro++;
    }
}

//$erro++, este ++ significa incrementação, ou seja, ele sempre irá adicionar +1 no seu valor atual, podemos fazer o mesmo com o --, decremento, ao contrário do
//incremento, ele irá decrementar, ou seja, diminuir 1 no seu valor atual.

//Para utilzar a validação, faremos o seguinte:

validaCampoObrigatorio($_POST, "nome", $erro);

//Caso não tenha sido enviado o nome, a variável erro, irá retornar o valor 1, neste caso.

if($erro != 0) {
    $msg = "O campo nome é obrigatório, por favor, preencha e envie o formulário novamente."
}

echo $msg;

//Temos a pasta PHPMailer_5.2.4, dentro dela, teremos os arquivos para o envio de email, então, bora lá

##Dados para envio do email
$enviaFormularioParaNome = 'Cadastro Site';
$enviaFormularioParaEmail = 'COLOQUE O EMAIL QUE RECEBERÁ O FORMULARIO AQUI';
$caixaPostalServidorNome = 'WebSite | Formulário de cadastro';
$caixaPostalServidorEmail = 'COLOQUE O EMAIL QUE ENVIARÁ A MENSAGEM AQUI';
$caixaPostalServidorSenha = 'COLOQUE A SENHA DO EMAIL AQUI';

$remetenteNome = "Cadastro site";
$remetenteEmail = "EMAIL DO REMETENTE, PODERÁ SER O MESMO QUE COLOCOU ACIMA";
$assunto = "Novo cadastro pelo site";
$mensagem = "
        Você recebeu uma mensagem através do site.<br />
        Nome: " . $nome . "
    ";

/*********************************** A PARTIR DAQUI NAO ALTERAR ************************************/

require("PHPMailer_5.2.4/class.phpmailer.php");

$mail = new PHPMailer();

$mail->IsSMTP();
$mail->SMTPAuth = true;
$mail->Charset = 'utf8_decode()';
$mail->Host = 'smtp.' . substr(strstr($caixaPostalServidorEmail, '@'), 1);
$mail->Port = '587';
$mail->Username = $caixaPostalServidorEmail;
$mail->Password = $caixaPostalServidorSenha;
$mail->From = $caixaPostalServidorEmail;
$mail->FromName = utf8_decode($caixaPostalServidorNome);
$mail->IsHTML(true);
$mail->Subject = utf8_decode($assunto);
$mail->Body = utf8_decode($mensagem);

$mail->AddAddress($enviaFormularioParaEmail, utf8_decode($enviaFormularioParaNome));

$mail->send();